=== Ultimate Addons for Gutenberg ===
Contributors: brainstormforce
Donate link: https://www.paypal.me/BrainstormForce
Tags: gutenberg, gutenberg free blocks, gutenberg addons, gutenberg addon, gutenberg addons, beaver builder lite, gutenberg blocks
Requires at least: 4.6
Requires PHP: 5.6
Tested up to: 4.9.6
Stable tag: 0.0.1
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

The Ultimate Addons for Gutenberg extends the Gutenberg functionality with several unique custom blocks.

== Description ==

<strong>The Ultimate Addons for Gutenberg</strong>

Supercharge Gutenberg with custom blocks. We have Advanced Heading Block as a start. We will add more blocks soon.

Note: Gutenberg is in an early stage of development so the Ultimate Addons for Gutenberg is also in early stage and may not be suitable for production sites. The breaking changes could be expected.

Feel free to contribute to the Gutenberg development.

== Installation ==

1. Install Ultimate Addon for Gutenberg either via the WordPress plugin directory or by uploading the files to your server at wp-content/plugins.

== Frequently Asked Questions ==

= Can I use Ultimate Addons for Gutenberg without Gutenberg? =

No.
The Ultimate Addons for Gutenberg is an addon for Gutenberg. You need Gutenberg to be activated.

== Screenshots ==

1. /assets/screenshots/1.png

== Changelog ==

= 0.0.1 =
* Initial release